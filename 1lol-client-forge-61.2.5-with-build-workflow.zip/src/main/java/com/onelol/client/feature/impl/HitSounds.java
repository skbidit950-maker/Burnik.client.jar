package com.onelol.client.feature.impl;
import com.onelol.client.feature.Feature;
public final class HitSounds extends Feature { public enum Style{CLASSIC,POP,METAL,THUNDER,ARCADE,CUSTOM} public Style style=Style.CLASSIC; public float volume=.8f,pitch=1; public HitSounds(){super("Hit Sounds");} }

package com.onelol.client.feature.impl;
import com.onelol.client.feature.Feature;
public final class BaseFinder extends Feature { public int scanRadius=128; public BaseFinder(){super("Base Finder");} }

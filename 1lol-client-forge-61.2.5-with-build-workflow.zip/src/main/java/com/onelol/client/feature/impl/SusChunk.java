package com.onelol.client.feature.impl;
import com.onelol.client.feature.Feature;
public final class SusChunk extends Feature { public int radius=6; public boolean showCoords=true, outline=true; public SusChunk(){super("Sus Chunk");} }

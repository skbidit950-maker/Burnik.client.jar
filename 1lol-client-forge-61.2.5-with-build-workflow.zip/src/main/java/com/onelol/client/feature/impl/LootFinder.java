package com.onelol.client.feature.impl;
import com.onelol.client.feature.Feature;
public final class LootFinder extends Feature { public LootFinder(){super("Loot Finder");} }

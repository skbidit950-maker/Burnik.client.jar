package com.onelol.client.feature.impl;
import com.onelol.client.feature.Feature;
public final class ChunkFinder extends Feature { public int radius=8; public ChunkFinder(){super("Chunk Finder");} }

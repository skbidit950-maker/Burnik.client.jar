package com.onelol.client.feature.impl;
import com.onelol.client.feature.Feature;
/** UI/settings scaffold only; target selection and rotation are not yet wired. */
public final class AimAssist extends Feature { public float strength=.35f, range=4f; public boolean playersOnly=true, visibleOnly=true; public AimAssist(){super("Aim Assist");} }

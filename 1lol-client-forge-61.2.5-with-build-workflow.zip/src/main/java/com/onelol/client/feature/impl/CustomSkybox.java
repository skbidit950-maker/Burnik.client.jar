package com.onelol.client.feature.impl;
import com.onelol.client.feature.Feature;
public final class CustomSkybox extends Feature { public enum Style{PURPLE_GALAXY,VOID,STARS,SUNSET,NEBULA} public Style style=Style.PURPLE_GALAXY; public float brightness=1,rotation=0; public CustomSkybox(){super("Custom Skybox");} }

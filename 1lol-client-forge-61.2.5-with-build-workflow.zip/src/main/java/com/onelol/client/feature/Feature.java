package com.onelol.client.feature;
public abstract class Feature {
 private final String name; private boolean enabled;
 protected Feature(String name){this.name=name;}
 public String name(){return name;} public boolean enabled(){return enabled;}
 public void setEnabled(boolean v){if(enabled==v)return;enabled=v;if(v)onEnable();else onDisable();}
 public void toggle(){setEnabled(!enabled);} protected void onEnable(){} protected void onDisable(){}
}

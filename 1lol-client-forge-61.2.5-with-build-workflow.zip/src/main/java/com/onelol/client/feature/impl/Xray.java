package com.onelol.client.feature.impl;
import com.onelol.client.feature.Feature;
/** Settings scaffold; ore render filters not yet hooked. */
public final class Xray extends Feature { public boolean diamond=true,emerald=true,gold=true,iron=true,redstone=true,lapis=true; public Xray(){super("Xray");} }

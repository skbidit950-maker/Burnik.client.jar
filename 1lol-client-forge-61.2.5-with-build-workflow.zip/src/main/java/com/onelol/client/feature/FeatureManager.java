package com.onelol.client.feature;
import java.util.*; import com.onelol.client.feature.impl.*;
public final class FeatureManager {
 public static final FeatureManager INSTANCE=new FeatureManager();
 private final List<Feature> features=List.of(new AimAssist(),new Xray(),new SusChunk(),new ChunkFinder(),new BaseFinder(),new Freecam(),new PlayerEsp(),new LootFinder(),new HitEffects(),new HitSounds(),new CustomSkybox());
 public List<Feature> all(){return features;}
 public Feature get(String name){return features.stream().filter(f->f.name().equalsIgnoreCase(name)).findFirst().orElse(null);}
}

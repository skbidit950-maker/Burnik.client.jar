package com.onelol.client.feature.impl;
import com.onelol.client.feature.Feature;
public final class Freecam extends Feature { public float speed=.5f; public Freecam(){super("Freecam");} }

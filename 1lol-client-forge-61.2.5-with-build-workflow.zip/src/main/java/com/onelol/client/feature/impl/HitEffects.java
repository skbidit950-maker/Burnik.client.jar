package com.onelol.client.feature.impl;
import com.onelol.client.feature.Feature;
public final class HitEffects extends Feature { public enum Style{PURPLE_LIGHTNING,HEARTS,STARS,FLAMES,SHOCKWAVE,SMOKE,RAINBOW,MINIMAL} public Style style=Style.PURPLE_LIGHTNING; public float intensity=1; public HitEffects(){super("Hit Effects");} }

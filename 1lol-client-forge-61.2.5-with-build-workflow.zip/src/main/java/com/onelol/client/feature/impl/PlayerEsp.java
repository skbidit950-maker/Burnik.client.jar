package com.onelol.client.feature.impl;
import com.onelol.client.feature.Feature;
public final class PlayerEsp extends Feature { public boolean names=true,distance=true; public PlayerEsp(){super("Player ESP");} }

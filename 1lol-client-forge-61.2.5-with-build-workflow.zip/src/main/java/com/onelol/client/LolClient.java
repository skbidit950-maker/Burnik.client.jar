package com.onelol.client;
import net.minecraftforge.fml.common.Mod;
@Mod(LolClient.MODID)
public final class LolClient { public static final String MODID="lolclient"; public LolClient(){} }

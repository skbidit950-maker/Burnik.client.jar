package com.onelol.client.gui;
import com.onelol.client.feature.*; import net.minecraft.client.gui.GuiGraphics; import net.minecraft.client.gui.screens.Screen; import net.minecraft.network.chat.Component;
/** Purple/black feature toggle UI. Click rows to toggle. */
public final class LolScreen extends Screen {
 private int x,y,w=230,h=240; private static final int ROW=17;
 public LolScreen(){super(Component.literal("1LOL Client"));}
 @Override public void render(GuiGraphics g,int mx,int my,float pt){
  x=(width-w)/2;y=(height-h)/2; g.fill(x,y,x+w,y+h,0xF00D0718);g.fill(x,y,x+w,y+3,0xFFB45CFF);
  g.drawString(font,"1LOL CLIENT",x+10,y+9,0xFFEBD5FF,false);g.drawString(font,"Touch a module to toggle",x+10,y+22,0xFFBBA6D0,false);
  int i=0;for(Feature f:FeatureManager.INSTANCE.all()){int yy=y+39+i*ROW;if(yy+ROW>y+h-3)break;boolean hover=mx>=x+7&&mx<=x+w-7&&my>=yy&&my<=yy+ROW;g.fill(x+7,yy,x+w-7,yy+ROW-1,hover?0xFF39204D:0xFF21112F);g.drawString(font,f.name(),x+12,yy+4,0xFFEDE2F6,false);g.drawString(font,f.enabled()?"ON":"OFF",x+w-31,yy+4,f.enabled()?0xFFB66CFF:0xFF8B8195,false);i++;}super.render(g,mx,my,pt);
 }
 @Override public boolean mouseClicked(double mx,double my,int button){if(button==0){int i=0;for(Feature f:FeatureManager.INSTANCE.all()){int yy=y+39+i*ROW;if(yy+ROW<=y+h-3&&mx>=x+7&&mx<=x+w-7&&my>=yy&&my<=yy+ROW){f.toggle();return true;}i++;}}return super.mouseClicked(mx,my,button);}
 @Override public boolean isPauseScreen(){return false;}
}
